"""PE-only source proposal. The operator must provision the offline host first."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import pwd
import uuid
import re
import signal
import stat
import subprocess

PACKAGE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def durable_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def record(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    durable_directory(path.parent)


def checked_manifest(expected):
    raw = (PACKAGE / "manifest.json").read_bytes()
    require(sha(raw) == expected, "independent package digest mismatch")
    entries = json.loads(raw)["files"]
    listed = set()
    for row in entries:
        relative = Path(row["path"])
        source = PACKAGE / relative
        require(not relative.is_absolute() and ".." not in relative.parts and source.resolve() == source, "invalid package path")
        data = source.read_bytes()
        require(len(data) == row["bytes"] and sha(data) == row["sha256"], "changed file " + str(relative))
        listed.add(str(relative))
    actual = {str(p.relative_to(PACKAGE)) for p in PACKAGE.rglob("*") if not p.is_dir()}
    require(actual == listed | {"manifest.json"} and len(entries) == len(listed), "unexpected or duplicate package entries")


def check_endpoint(t):
    uid = pwd.getpwnam(t["server_os_user"]).pw_uid
    require(uid == os.geteuid() and pwd.getpwuid(uid).pw_name == t["operator"], "direct local peer identities must agree")
    socket_dir = Path(t["socket_dir"])
    data_dir = Path(t["pgdata"])
    hba = data_dir / "pg_hba.conf"
    for directory in {socket_dir, data_dir, *socket_dir.parents, *data_dir.parents}:
        st = directory.lstat()
        require(stat.S_ISDIR(st.st_mode) and st.st_uid in (0, uid) and not st.st_mode & 0o022,
                "unprotected directory or ancestor")
    mode = socket_dir.lstat()
    require(mode.st_uid == uid and not mode.st_mode & 0o077, "server socket directory must be private")
    sock = (socket_dir / (".s.PGSQL." + str(t["port"]))).lstat()
    require(stat.S_ISSOCK(sock.st_mode) and sock.st_uid == uid, "unexpected socket file or owner")
    st = hba.lstat()
    require(stat.S_ISREG(st.st_mode) and st.st_uid in (0, uid) and not st.st_mode & 0o022, "untrusted HBA file")
    raw = hba.read_bytes()
    require(sha(raw) == t["hba_sha256"], "HBA differs from approved bytes")
    rules = [line.split("#",1)[0].split() for line in raw.decode("ascii").splitlines()]
    require([entry for entry in rules if entry] == [["local", t["database"], t["operator"], "peer"]],
            "compiler HBA must contain only the approved direct peer rule")


def snapshot_hashes(raw):
    prefix = b"B017_SNAPSHOT="
    return [sha(line[len(prefix):]) for line in raw.splitlines() if line.startswith(prefix)]


def recovery_evidence(path, pinned, manifest, target, t):
    require(path is not None and path.is_absolute() and path.resolve(strict=True)==path and path.name=="install.json",
            "original cycle install receipt required")
    raw = path.read_bytes()
    require(sha(raw)==pinned, "original install receipt not approved")
    stage = json.loads(raw)
    require(stage["operation"]=="cycle" and stage["stage"]=="install" and stage["exit"]==0
            and stage["script"]=="install.proposed.sql" and stage["manifest"]==manifest and stage["target"]==target
            and stage["physical_target"]==[t["cluster_system_id"], t["pgdata"], t["database"]]
            and re.fullmatch("[0-9a-f]{32}", stage["run_id"]), "original install provenance mismatch")
    parent = path.parent
    def evidence_file(name):
        f = parent/name
        require(f.resolve(strict=True)==f and stat.S_ISREG(f.lstat().st_mode), "invalid evidence path")
        return f.read_bytes()
    baseline_raw = evidence_file("baseline.json")
    require(sha(baseline_raw)==stage["parent_baseline_receipt"], "original baseline stage changed")
    baseline = json.loads(baseline_raw)
    require(baseline["run_id"]==stage["run_id"] and baseline["manifest"]==manifest and baseline["target"]==target
            and baseline["operation"]=="cycle" and baseline["stage"]=="baseline" and baseline["exit"]==0
            and baseline["script"]=="baseline.sql" and baseline["physical_target"]==stage["physical_target"],
            "baseline belongs to another run")
    for item,count in ((baseline,1),(stage,2)):
        output = evidence_file(item["stage"]+".stdout")
        require(sha(output)==item["stdout"] and sha(evidence_file(item["stage"]+".stderr"))==item["stderr"]
                and len(item["snapshots"])==count and snapshot_hashes(output)==item["snapshots"], "raw evidence mismatch")
    base, sealed = stage["snapshots"]
    require(base!=sealed and base==stage["expected_baseline"]==baseline["snapshots"][0], "invalid original baseline/seal pair")
    return base, sealed


def checked_target(path):
    raw = path.read_bytes()
    t = json.loads(raw)
    required = {"cluster_system_id", "operator", "database", "socket_dir", "port", "pgdata",
                "psql", "psql_sha256", "runtime_roles", "isolated_cluster_approval", "server_os_user", "hba_sha256"}
    require(set(t) == required and t["isolated_cluster_approval"] == "DEDICATED_OFFLINE_NO_WORKERS", "incomplete compiler target")
    require(re.fullmatch(r"[1-9][0-9]{0,19}", t["cluster_system_id"]), "invalid system identifier")
    require(re.fullmatch(r"condola_b017_compiler_[a-z0-9_]{1,40}", t["database"]), "invalid compiler database")
    require(isinstance(t["port"], int) and 1 <= t["port"] <= 65535, "invalid port")
    roles = t["runtime_roles"]
    require(isinstance(roles, list) and set(roles) >= {"anon","authenticated","service_role"}
            and len(set(roles)) == len(roles) and t["operator"] not in roles, "invalid runtime inventory")
    for role in roles + [t["operator"]]:
        require(re.fullmatch(r"[a-z_][a-z0-9_]{0,62}", role), "invalid role identifier")
    for key in ("pgdata", "psql", "socket_dir"):
        p = Path(t[key])
        require(p.is_absolute() and p.resolve(strict=True) == p, "canonical absolute paths required")
    data_dir = Path(t["pgdata"]).stat()
    require(stat.S_ISDIR(data_dir.st_mode) and data_dir.st_uid == os.geteuid() and not data_dir.st_mode & 0o022, "operator must own protected data directory")
    require(Path(t["socket_dir"]).is_dir() and Path(t["psql"]).name == "psql"
            and sha(Path(t["psql"]).read_bytes()) == t["psql_sha256"], "invalid client/socket")
    check_endpoint(t)
    return t, sha(raw)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("operation", choices=["baseline", "cycle", "recover-down"])
    p.add_argument("--target", type=Path, required=True)
    p.add_argument("--manifest-sha256", required=True)
    p.add_argument("--target-sha256", required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--baseline-sha256")
    p.add_argument("--original-install-receipt", type=Path)
    p.add_argument("--original-install-sha256")
    a = p.parse_args()
    require(platform.system() == "Linux" and os.geteuid() != 0, "dedicated non-root Linux operator required")
    checked_manifest(a.manifest_sha256)
    t, target_sha = checked_target(a.target)
    require(target_sha == a.target_sha256, "use the separately approved target digest")
    if a.operation == "cycle":
        require(re.fullmatch("[0-9a-f]{64}", a.baseline_sha256 or ""), "approved baseline digest required")
    if a.operation == "recover-down":
        require(a.baseline_sha256 is None, "recovery cannot accept an independent state digest")
        recovery_base, recovery_seal = recovery_evidence(a.original_install_receipt, a.original_install_sha256,
                                                        a.manifest_sha256, target_sha, t)
    os.umask(0o077)
    out = a.output.absolute()
    require(out.resolve() == out and not any(x in out.parents for x in (PACKAGE,Path(t["pgdata"]))) and out != PACKAGE, "invalid receipt path")
    out.mkdir(mode=0o700, exist_ok=False)
    durable_directory(out.parent)
    cmd = [t["psql"], "-XqAtw", "-h", t["socket_dir"], "-p", str(t["port"]), "-U", t["operator"], "-d", t["database"]]
    env = {"PATH":"/usr/bin:/bin", "LC_ALL":"C", "PGCLIENTENCODING":"UTF8", "HOME":str(out),
           "PGREQUIREPEER":t["server_os_user"], "PGPASSFILE":"/dev/null", "PGCONNECT_TIMEOUT":"5", "PGAPPNAME":"b017_compiler_operator"}
    lane = Path(t["pgdata"]) / (".b017-compiler-" + t["cluster_system_id"] + ".lock")
    run_id = uuid.uuid4().hex
    state = {"run_id":run_id,"original_install":a.original_install_sha256,"operation":a.operation, "manifest":a.manifest_sha256, "target":target_sha, "stages":[], "status":"INCOMPLETE"}
    with os.fdopen(os.open(lane, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600), "r+b") as lock:
        st = os.fstat(lock.fileno())
        require(stat.S_ISREG(st.st_mode) and st.st_uid==os.geteuid() and st.st_nlink==1 and not st.st_mode & 0o077, "unsafe lock file")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        def stage(label, script, expected="", original=""):
            check_endpoint(t)
            args = cmd.copy()
            for key,val in dict(sysid=t["cluster_system_id"], dbname=t["database"], operator=t["operator"],
                                runtime_json=json.dumps(t["runtime_roles"]), pgdata=t["pgdata"],expected=expected,original=original).items():
                args += ["-v",key+"="+val]
            stdout = out / (label+".stdout")
            stderr = out / (label+".stderr")
            with stdout.open("xb") as so, stderr.open("xb") as se:
                child = subprocess.Popen(args+["-f",str(PACKAGE/script)], cwd=PACKAGE, env=env, stdin=subprocess.DEVNULL,
                                         stdout=so, stderr=se, start_new_session=True, pass_fds=(lock.fileno(),))
                try:
                    rc = child.wait(timeout=180)
                finally:
                    if child.poll() is None:
                        child.terminate()
                        try:
                            child.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            child.kill()
                            child.wait()
                os.fsync(so.fileno())
                os.fsync(se.fileno())
            raw = stdout.read_bytes()
            snapshots = snapshot_hashes(raw)
            step = {"stage":label,"exit":rc,"stdout":sha(raw),"stderr":sha(stderr.read_bytes()),"snapshots":snapshots}
            step.update(operation=a.operation, manifest=a.manifest_sha256, target=target_sha, script=script,
                        run_id=run_id, physical_target=[t["cluster_system_id"], t["pgdata"], t["database"]])
            if label == "install":
                step.update(expected_baseline=expected, parent_baseline_receipt=sha((out/"baseline.json").read_bytes()))
            state["stages"].append(step)
            record(out/(label+".json"),step)
            require(rc == 0, "compiler failed at "+label)
            expected_count = 2 if script in ("install.proposed.sql","down.proposed.sql") else 1
            require(len(snapshots) == expected_count, "incomplete snapshot readback")
            return snapshots[-1]
        try:
            if a.operation != "recover-down":
                base = stage("baseline", "baseline.sql")
                if a.operation == "cycle":
                    require(base == a.baseline_sha256, "approved baseline changed")
                    sealed = stage("install","install.proposed.sql",base)
                    stage("committed-seal","sealed-readback.sql",sealed)
            if a.operation != "baseline":
                base = a.baseline_sha256
                if a.operation == "recover-down":
                    base, sealed = recovery_base, recovery_seal
                    stage("committed-seal","sealed-readback.sql",sealed)
                stage("remove","down.proposed.sql",sealed,base)
                require(stage("restored","baseline.sql")==base, "post-removal baseline mismatch")
            state["status"]="COMPILER_"+a.operation.upper().replace("-","_")+"_FINISHED"
        finally:
            record(out/"receipt.json",state)


if __name__ == "__main__":
    def stop(signum, frame):
        raise KeyboardInterrupt("operator interrupted")
    signal.signal(signal.SIGTERM, stop)
    main()
