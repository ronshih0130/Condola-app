\set ON_ERROR_STOP on
BEGIN;
\ir sql/guard.sql
\ir sql/inventory.sql
\ir sql/preflight.sql
\ir sql/snapshot.sql
\ir sql/match.sql
SELECT (:'snapshot'::jsonb)->'parent_triggers' AS parents_before, (:'snapshot'::jsonb)->'controls' AS controls_before \gset
\ir inputs/01-authority-core.sql
\ir inputs/02a-role-create-v2.sql
\ir inputs/02b-role-edit-unassigned.sql
\ir sql/seal.sql
\ir sql/assert-sealed.sql
\ir sql/snapshot.sql
\ir sql/parent-fk-delta.sql
SELECT 1 / (((( :'snapshot'::jsonb)->'controls')=:'controls_before'::jsonb)::integer);
COMMIT;
