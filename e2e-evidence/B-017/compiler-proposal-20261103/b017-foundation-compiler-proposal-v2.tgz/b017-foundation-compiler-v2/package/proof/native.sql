-- Normal authenticated RLS entry paths, before and after compile on the SAME isolated synthetic baseline.
CREATE TEMP TABLE b17_native_results(facet text PRIMARY KEY, result text) ON COMMIT DROP;
GRANT INSERT ON pg_temp.b17_native_results TO authenticated;
DO $compat$
DECLARE z record; props bigint; bills bigint; msgs bigint; flags bigint; visits integer:=0;
BEGIN
 FOR z IN
  (SELECT DISTINCT ON(m.role) m.role::text AS persona,m.user_id actor,m.org_id org FROM public.org_members m JOIN public.organizations o ON o.id=m.org_id WHERE m.status='active' AND o.environment='live' ORDER BY m.role,m.org_id,m.id)
  UNION ALL
  (SELECT DISTINCT ON(persona) x.* FROM (SELECT CASE WHEN c.is_tenant THEN 'tenant' ELSE 'owner' END persona,c.user_id actor,c.org_id org FROM public.contacts c JOIN public.organizations o ON o.id=c.org_id WHERE o.environment='live' AND c.user_id IS NOT NULL AND (c.is_tenant OR c.is_owner) AND c.archived_at IS NULL) x ORDER BY persona,actor)
 LOOP
  PERFORM set_config('request.jwt.claim.sub',z.actor::text,true);
  PERFORM set_config('request.jwt.claim.role','authenticated',true);
  PERFORM set_config('app.active_org_id',z.org::text,true);
  PERFORM set_config('app.env','live',true);
  SET LOCAL ROLE authenticated;
  SELECT count(*) INTO props FROM public.properties;
  SELECT count(*) INTO bills FROM public.payments;
  SELECT count(*) INTO msgs FROM public.messages;
  SELECT count(*) INTO flags FROM public.platform_settings;
  INSERT INTO pg_temp.b17_native_results VALUES(z.persona,jsonb_build_array(props,bills,msgs,flags)::text);
  RESET ROLE;
  visits:=visits+1;
 END LOOP;
 IF visits<>6 THEN RAISE EXCEPTION 'Synthetic baseline needs four staff personas plus tenant and owner'; END IF;
END $compat$;
SELECT 'B017_NATIVE='||jsonb_object_agg(facet,result ORDER BY facet)::text FROM pg_temp.b17_native_results;
