-- Disposable proof child only. The invoking transaction must ROLLBACK.
DO $child$ BEGIN
 IF current_database() !~ '^condola_b017_compiler_fixture_' THEN RAISE EXCEPTION 'Fixture clone only'; END IF;
END $child$;
SELECT m.org_id::text AS org, m.user_id::text AS actor, m.id::text AS member, gen_random_uuid()::text AS sid
FROM public.org_members m JOIN public.organizations o ON o.id=m.org_id
WHERE m.role::text='admin' AND m.status::text='active' AND o.environment::text='live' AND o.live_org_id IS NULL
AND EXISTS(SELECT 1 FROM public.org_members z WHERE z.org_id=m.org_id AND z.id<>m.id) ORDER BY m.org_id,m.id LIMIT 1
\gset
SELECT z.id::text other_member FROM public.org_members z WHERE z.org_id=:'org'::uuid AND z.id<>:'member'::uuid ORDER BY z.id LIMIT 1
\gset
INSERT INTO public.auth_sessions(id,user_id,token_hash,expires_at)
VALUES(:'sid'::uuid,:'actor'::uuid,encode(sha256(convert_to(gen_random_uuid()::text,'UTF8')),'hex'),clock_timestamp()+interval '15 minutes');
INSERT INTO public.platform_settings(key,value) VALUES('custom_roles',jsonb_build_object('enabled',true,'allowed_org_ids',jsonb_build_array(:'org'::text)))
ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value;
UPDATE public.organizations SET feature_flags=feature_flags||'{"custom_roles":true}'::jsonb WHERE id=:'org'::uuid;
SELECT set_config('request.jwt.claim.sub',:'actor',true),set_config('app.active_org_id',:'org',true),set_config('app.env','live',true),
 set_config('b017_fixture.sid',:'sid',true),set_config('b017_fixture.other',:'other_member',true);
CREATE FUNCTION app.b017_disposable_audit_fault() RETURNS trigger LANGUAGE plpgsql AS $audit$
BEGIN
 IF NEW.table_name='b017_roles' AND current_setting('b017_fixture.fail_audit',true)='yes' THEN
  RAISE EXCEPTION 'injected audit write failure' USING ERRCODE='P1701';
 END IF;
 RETURN NEW;
END $audit$;
CREATE TRIGGER b017_disposable_audit_fault BEFORE INSERT ON public.audit_log FOR EACH ROW EXECUTE FUNCTION app.b017_disposable_audit_fault();
SET LOCAL ROLE b017_authority_owner;
DO $test$
DECLARE o uuid:=current_setting('app.active_org_id')::uuid; u uuid:=current_setting('request.jwt.claim.sub')::uuid;
 s uuid:=current_setting('b017_fixture.sid')::uuid; roleid uuid:=gen_random_uuid(); create_request uuid:=gen_random_uuid(); edit_request uuid:=gen_random_uuid(); badrole uuid:=gen_random_uuid();
 k text[]:=ARRAY['bank.reconcile']; c record; cmd record; before_n integer; caught boolean:=false;
BEGIN
 IF cardinality(app.b017_recognized_keys_v1())<>18 OR cardinality(app.b017_supported_keys_v1())<>17
 OR NOT app.b017_keys_supported_v1(ARRAY[]::text[]) OR app.b017_keys_supported_v1(NULL::text[])
 OR app.b017_keys_supported_v1(ARRAY['data.export']) OR app.b017_keys_supported_v1(ARRAY['dash.view','dash.view'])
 OR app.b017_keys_supported_v1(ARRAY['props.view','dash.view']) OR app.b017_keys_supported_v1(ARRAY[NULL::text])
 OR cardinality(app.b017_native_keys_v1('admin'))<>17 OR cardinality(app.b017_native_keys_v1('manager'))<>11
 OR cardinality(app.b017_native_keys_v1('accountant'))<>10 OR cardinality(app.b017_native_keys_v1('maintenance'))<>2
 OR app.b017_role_name_valid(U&'\3000\200B') OR NOT app.b017_role_name_valid('維修團隊')
 OR app.b017_role_name_key('Ａ d m i n')<>'admin' OR app.b017_role_name_key(U&'\3000管理員')<>'管理員' THEN RAISE EXCEPTION 'Catalog/name vector failed'; END IF;
 SELECT * INTO c FROM app.b017_effective_context(s,o,'live');
 IF c.status IS DISTINCT FROM 'ready' OR cardinality(c.effective_keys)<>17 THEN RAISE EXCEPTION 'Native context failed'; END IF;
 PERFORM set_config('app.active_org_id',gen_random_uuid()::text,true);
 SELECT * INTO c FROM app.b017_effective_context(s,o,'live');
 IF c.status IS DISTINCT FROM 'unavailable' THEN RAISE EXCEPTION 'Mismatched company admitted'; END IF;
 PERFORM set_config('app.active_org_id',o::text,true);
 INSERT INTO app.b017_org_state(live_org_id,enforcement_state,capability_version,authority_revision,support_manifest_sha256)
 VALUES(o,'prepared',1,1,app.b017_support_digest_v1());
 SELECT * INTO cmd FROM app.b017_create_role(s,o,'live',create_request,roleid,1,'管理員',k);
 IF cmd.outcome IS DISTINCT FROM 'unavailable' THEN RAISE EXCEPTION 'Native label admitted'; END IF;
 SELECT * INTO cmd FROM app.b017_create_role(s,o,'live',create_request,roleid,1,'維修團隊',k);
 IF cmd.outcome IS DISTINCT FROM 'created' OR cmd.role_revision<>1 OR cmd.authority_revision<>2 THEN RAISE EXCEPTION 'Create vector failed'; END IF;
 SELECT * INTO cmd FROM app.b017_edit_unassigned_role(s,o,'live',edit_request,roleid,1,2,'維修＋查帳',k);
 IF cmd.outcome IS DISTINCT FROM 'updated' OR cmd.role_revision<>2 OR cmd.authority_revision<>3 THEN RAISE EXCEPTION 'Edit vector failed'; END IF;
 SELECT * INTO cmd FROM app.b017_create_role(s,o,'live',create_request,roleid,1,'維修團隊',k);
 IF cmd.outcome IS DISTINCT FROM 'replayed' OR cmd.role_revision<>1 OR cmd.authority_revision<>2 THEN RAISE EXCEPTION 'Original create replay failed'; END IF;
 SELECT * INTO cmd FROM app.b017_edit_unassigned_role(s,o,'live',edit_request,roleid,1,2,'DIFFERENT',k);
 IF cmd.outcome IS DISTINCT FROM 'conflict' THEN RAISE EXCEPTION 'Changed intent was not conflict'; END IF;
 INSERT INTO app.b017_assignments(org_id,member_id,role_id,revision,assigned_by) VALUES(o,current_setting('b017_fixture.other')::uuid,roleid,1,u);
 SELECT * INTO cmd FROM app.b017_edit_unassigned_role(s,o,'live',gen_random_uuid(),roleid,2,3,'Assigned',k);
 IF cmd.outcome IS DISTINCT FROM 'in_use' THEN RAISE EXCEPTION 'Assigned edit admitted'; END IF;
 SELECT * INTO cmd FROM app.b017_edit_unassigned_role(s,o,'live',edit_request,roleid,1,2,'維修＋查帳',k);
 IF cmd.outcome IS DISTINCT FROM 'replayed' OR cmd.role_revision<>2 OR cmd.authority_revision<>3 THEN RAISE EXCEPTION 'Original edit replay failed'; END IF;
 SELECT * INTO cmd FROM app.b017_create_role(s,o,'live',gen_random_uuid(),badrole,1,'Stale',k);
 IF cmd.outcome IS DISTINCT FROM 'stale' THEN RAISE EXCEPTION 'Stale create admitted'; END IF;
 PERFORM set_config('b017_fixture.fail_audit','yes',true);
 BEGIN
  PERFORM * FROM app.b017_create_role(s,o,'live',gen_random_uuid(),badrole,3,'Atomic test',k);
 EXCEPTION WHEN SQLSTATE 'P1701' THEN caught:=true;
 END;
 IF NOT caught OR EXISTS(SELECT 1 FROM app.b017_roles WHERE org_id=o AND role_id=badrole)
 OR (SELECT authority_revision FROM app.b017_org_state WHERE live_org_id=o)<>3
 OR (SELECT count(*) FROM app.b017_commands WHERE org_id=o)<>2 THEN RAISE EXCEPTION 'Audit failure did not roll back'; END IF;
 BEGIN
  UPDATE public.organizations SET id=o WHERE id=o;
  IF FOUND THEN RAISE EXCEPTION 'Lock privilege allowed real UPDATE'; END IF;
 EXCEPTION WHEN insufficient_privilege THEN NULL;
 END;
END $test$;
RESET ROLE;
SELECT 1/(count(*)=2)::int FROM public.audit_log WHERE org_id=:'org'::uuid AND table_name='b017_roles' AND actor_role='b017_authority_owner';
