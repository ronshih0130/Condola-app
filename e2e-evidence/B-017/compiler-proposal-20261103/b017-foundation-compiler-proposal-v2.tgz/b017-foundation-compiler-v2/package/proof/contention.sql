-- Run while second operator session holds the existing live organization row.
DO $busy$
DECLARE observed boolean:=false;
BEGIN
 BEGIN
  PERFORM 1 FROM public.organizations o WHERE o.id=current_setting('b017_fixture.org')::uuid FOR UPDATE NOWAIT;
 EXCEPTION WHEN lock_not_available THEN observed:=true;
 END;
 IF NOT observed THEN RAISE EXCEPTION 'Expected separate-client row lock not observed'; END IF;
END $busy$;
