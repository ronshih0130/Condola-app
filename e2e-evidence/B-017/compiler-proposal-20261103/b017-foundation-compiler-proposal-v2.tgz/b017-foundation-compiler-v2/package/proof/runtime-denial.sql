-- This whole transaction is rolled back. Runtime roles must never gain private access.
DO $denials$
DECLARE u text; f text; tbl text; cmd text; blocked boolean;
BEGIN
 FOR u IN SELECT jsonb_array_elements_text(current_setting('b017_compiler.runtime')::jsonb) LOOP
  FOREACH cmd IN ARRAY ARRAY[
   'SELECT app.b017_recognized_keys_v1()', 'SELECT app.b017_supported_keys_v1()',
   'SELECT app.b017_keys_supported_v1(ARRAY[]::text[])', 'SELECT app.b017_native_keys_v1(''admin'')',
   'SELECT app.b017_support_digest_v1()', 'SELECT * FROM app.b017_effective_context(NULL,NULL,''live'')',
   'SELECT app.b017_role_name_valid(''test'')','SELECT app.b017_role_name_key(''test'')',
   'SELECT * FROM app.b017_create_role(NULL,NULL,''live'',NULL,NULL,1,''test'',ARRAY[]::text[])',
   'SELECT * FROM app.b017_edit_unassigned_role(NULL,NULL,''live'',NULL,NULL,1,1,''test'',ARRAY[]::text[])',
   'SELECT * FROM app.b017_org_state','SELECT * FROM app.b017_roles','SELECT * FROM app.b017_assignments','SELECT * FROM app.b017_commands',
   'INSERT INTO app.b017_org_state DEFAULT VALUES','INSERT INTO app.b017_roles DEFAULT VALUES',
   'INSERT INTO app.b017_assignments DEFAULT VALUES','INSERT INTO app.b017_commands DEFAULT VALUES'] LOOP
   blocked:=false;
   EXECUTE format('SET LOCAL ROLE %I',u);
   BEGIN EXECUTE cmd; EXCEPTION WHEN insufficient_privilege THEN blocked:=true; END;
   RESET ROLE;
   IF NOT blocked THEN RAISE EXCEPTION 'Runtime operation admitted for %',u; END IF;
  END LOOP;
 END LOOP;
END $denials$;
