-- SOURCE FRAGMENT ONLY: unparsed, unapplied, incomplete; never execute separately.
-- Requires reviewed composition, approved target catalog/role/ACL checks and all later stages.
CREATE ROLE b017_authority_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT;
CREATE ROLE b017_domain_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT;

CREATE FUNCTION app.b017_recognized_keys_v1() RETURNS text[] LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path=pg_catalog AS $$
 SELECT ARRAY['bank.reconcile','dash.view','data.export','exp.add','leases.edit','messages.send','month.close','pay.record','pay.reverse','props.edit','props.view','reports.export','settings.edit','stmt.generate','stmt.view','team.manage','tenants.contact','tickets.update']::text[]
$$;
CREATE FUNCTION app.b017_supported_keys_v1() RETURNS text[] LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path=pg_catalog AS $$
 SELECT ARRAY['bank.reconcile','dash.view','exp.add','leases.edit','messages.send','month.close','pay.record','pay.reverse','props.edit','props.view','reports.export','settings.edit','stmt.generate','stmt.view','team.manage','tenants.contact','tickets.update']::text[]
$$;
CREATE FUNCTION app.b017_keys_supported_v1(v text[]) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path=pg_catalog AS $$
 SELECT v IS NOT NULL AND pg_catalog.array_ndims(v) IS NOT DISTINCT FROM CASE WHEN pg_catalog.cardinality(v)=0 THEN NULL ELSE 1 END
 AND NOT EXISTS (SELECT 1 FROM pg_catalog.unnest(v) AS t(k) WHERE k IS NULL OR NOT (k=ANY(app.b017_supported_keys_v1())))
 AND v = COALESCE((SELECT pg_catalog.array_agg(k ORDER BY k COLLATE "C") FROM (SELECT DISTINCT k FROM pg_catalog.unnest(v) AS t(k)) s), ARRAY[]::text[])
$$;
CREATE FUNCTION app.b017_native_keys_v1(v public.org_role) RETURNS text[] LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE SET search_path=pg_catalog AS $$
 SELECT CASE v::text
 WHEN 'admin' THEN app.b017_supported_keys_v1()
 WHEN 'manager' THEN ARRAY['dash.view','exp.add','leases.edit','messages.send','pay.record','props.edit','props.view','reports.export','stmt.view','tenants.contact','tickets.update']::text[]
 WHEN 'accountant' THEN ARRAY['bank.reconcile','dash.view','exp.add','month.close','pay.record','pay.reverse','props.view','reports.export','stmt.generate','stmt.view']::text[]
 WHEN 'maintenance' THEN ARRAY['tenants.contact','tickets.update']::text[]
 ELSE NULL END
$$;
CREATE FUNCTION app.b017_support_digest_v1() RETURNS bytea LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path=pg_catalog AS $$
 SELECT pg_catalog.sha256(pg_catalog.convert_to(pg_catalog.array_to_json(app.b017_supported_keys_v1())::text,'UTF8'))
$$;

CREATE TABLE app.b017_org_state (
 live_org_id uuid PRIMARY KEY REFERENCES public.organizations(id),
 enforcement_state text NOT NULL CHECK(enforcement_state IN ('prepared','enforced')),
 capability_version integer NOT NULL CHECK(capability_version=1),
 authority_revision bigint NOT NULL CHECK(authority_revision>0),
 support_manifest_sha256 bytea NOT NULL CHECK(octet_length(support_manifest_sha256)=32),
 photo_issuance_fenced_at timestamptz, vendor_bearers_retired_at timestamptz, enrolled_at timestamptz,
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 CHECK(enforcement_state <> 'enforced' OR (photo_issuance_fenced_at IS NOT NULL AND vendor_bearers_retired_at IS NOT NULL AND enrolled_at IS NOT NULL))
);
CREATE TABLE app.b017_roles (
 org_id uuid NOT NULL REFERENCES app.b017_org_state(live_org_id), role_id uuid NOT NULL,
 display_name text NOT NULL CHECK(char_length(display_name) BETWEEN 1 AND 120),
 name_key text NOT NULL CHECK(char_length(name_key) BETWEEN 1 AND 120),
 keys text[] NOT NULL CHECK(app.b017_keys_supported_v1(keys)), revision bigint NOT NULL CHECK(revision>0),
 lifecycle text NOT NULL CHECK(lifecycle IN ('draft','active','retired')),
 created_by uuid NOT NULL, updated_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT clock_timestamp(), updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(org_id,role_id), UNIQUE(org_id,name_key)
);
CREATE TABLE app.b017_assignments (
 org_id uuid NOT NULL REFERENCES app.b017_org_state(live_org_id), member_id uuid NOT NULL,
 role_id uuid, revision bigint NOT NULL CHECK(revision>0), assigned_by uuid NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(), PRIMARY KEY(org_id,member_id),
 FOREIGN KEY(org_id,member_id) REFERENCES public.org_members(org_id,id),
 FOREIGN KEY(org_id,role_id) REFERENCES app.b017_roles(org_id,role_id)
);
CREATE TABLE app.b017_commands (
 org_id uuid NOT NULL REFERENCES app.b017_org_state(live_org_id), actor_member_id uuid NOT NULL,
 request_id uuid NOT NULL, command text NOT NULL CHECK(command IN ('role_create','role_edit','role_retire','role_assign','role_unassign','member_set_role','member_set_status','member_invite','member_invite_rotate','member_invite_revoke','member_invite_accept')),
 target_id uuid, intent_sha256 bytea NOT NULL CHECK(octet_length(intent_sha256)=32),
 expected_revisions jsonb NOT NULL CHECK(jsonb_typeof(expected_revisions)='object'),
 result_identity jsonb NOT NULL CHECK(jsonb_typeof(result_identity)='object'),
 committed_at timestamptz NOT NULL DEFAULT clock_timestamp(), PRIMARY KEY(org_id,actor_member_id,request_id),
 FOREIGN KEY(org_id,actor_member_id) REFERENCES public.org_members(org_id,id)
);
ALTER TABLE app.b017_org_state OWNER TO b017_authority_owner;
ALTER TABLE app.b017_roles OWNER TO b017_authority_owner;
ALTER TABLE app.b017_assignments OWNER TO b017_authority_owner;
ALTER TABLE app.b017_commands OWNER TO b017_authority_owner;
ALTER TABLE app.b017_org_state ENABLE ROW LEVEL SECURITY; ALTER TABLE app.b017_org_state FORCE ROW LEVEL SECURITY;
ALTER TABLE app.b017_roles ENABLE ROW LEVEL SECURITY; ALTER TABLE app.b017_roles FORCE ROW LEVEL SECURITY;
ALTER TABLE app.b017_assignments ENABLE ROW LEVEL SECURITY; ALTER TABLE app.b017_assignments FORCE ROW LEVEL SECURITY;
ALTER TABLE app.b017_commands ENABLE ROW LEVEL SECURITY; ALTER TABLE app.b017_commands FORCE ROW LEVEL SECURITY;
CREATE POLICY b017_owner ON app.b017_org_state TO b017_authority_owner USING(true) WITH CHECK(true);
CREATE POLICY b017_owner ON app.b017_roles TO b017_authority_owner USING(true) WITH CHECK(true);
CREATE POLICY b017_owner ON app.b017_assignments TO b017_authority_owner USING(true) WITH CHECK(true);
CREATE POLICY b017_owner ON app.b017_commands TO b017_authority_owner USING(true) WITH CHECK(true);
REVOKE ALL ON app.b017_org_state,app.b017_roles,app.b017_assignments,app.b017_commands FROM PUBLIC,anon,authenticated,service_role;
-- Narrow read privileges for the private fixed resolver. RLS policies must not recurse
-- into B017 helpers. No worker receives membership in either owner role.
GRANT USAGE ON SCHEMA app,public,auth TO b017_authority_owner;
GRANT EXECUTE ON FUNCTION auth.uid() TO b017_authority_owner;
GRANT SELECT(id,user_id,expires_at,revoked_at) ON public.auth_sessions TO b017_authority_owner;
GRANT SELECT(id,environment,live_org_id) ON public.organizations TO b017_authority_owner;
GRANT SELECT(id,org_id,user_id,role,status,is_billing_owner,updated_at) ON public.org_members TO b017_authority_owner;
CREATE POLICY b017_authority_session_read ON public.auth_sessions FOR SELECT TO b017_authority_owner USING(true);
CREATE POLICY b017_authority_org_read ON public.organizations FOR SELECT TO b017_authority_owner USING(true);
CREATE POLICY b017_authority_member_read ON public.org_members FOR SELECT TO b017_authority_owner USING(true);

-- The adapter MUST authenticate the actual cookie, bind auth.uid(), check canonical
-- consent and partner policy in this same transaction, and hold/recheck rows for writes.
-- Exact transaction pins corroborate the selected scope; neither pins nor SID are credentials.
-- This reader is not a lock.
CREATE FUNCTION app.b017_effective_context(p_session uuid,p_org uuid,p_env text)
RETURNS TABLE(status text,actor_user_id uuid,live_org_id uuid,member_id uuid,native_role text,effective_keys text[],enforcement_state text,authority_revision bigint,assignment_revision bigint,role_revision bigint,context_digest bytea)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $ctx$
DECLARE a uuid; l uuid; env text; m public.org_members%ROWTYPE; st app.b017_org_state%ROWTYPE; asn app.b017_assignments%ROWTYPE; r app.b017_roles%ROWTYPE; ks text[]; ar bigint; rr bigint; mode text; digest bytea;
BEGIN
 a:=auth.uid();
 IF a IS NULL OR p_session IS NULL OR p_org IS NULL OR p_env IS NULL OR p_env NOT IN ('live','sandbox') OR nullif(current_setting('app.active_org_id',true),'') IS DISTINCT FROM p_org::text OR nullif(current_setting('app.env',true),'') IS DISTINCT FROM p_env OR NOT EXISTS(SELECT 1 FROM public.auth_sessions s WHERE s.id=p_session AND s.user_id=a AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp()) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
 SELECT o.environment::text,CASE WHEN o.environment::text='live' AND o.live_org_id IS NULL THEN o.id ELSE o.live_org_id END INTO env,l FROM public.organizations o WHERE o.id=p_org;
 IF env IS DISTINCT FROM p_env OR l IS NULL OR NOT EXISTS(SELECT 1 FROM public.organizations o WHERE o.id=l AND o.environment::text='live' AND o.live_org_id IS NULL) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
 SELECT om.id,om.org_id,om.user_id,om.role,om.status,om.is_billing_owner,om.updated_at INTO m.id,m.org_id,m.user_id,m.role,m.status,m.is_billing_owner,m.updated_at FROM public.org_members om WHERE om.org_id=l AND om.user_id=a AND om.status::text='active';
 IF NOT FOUND THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
 SELECT s.* INTO st FROM app.b017_org_state s WHERE s.live_org_id=l;
 IF NOT FOUND THEN mode:='native'; ks:=app.b017_native_keys_v1(m.role); ar:=NULL; rr:=NULL;
 ELSE
  IF st.capability_version<>1 OR st.support_manifest_sha256 IS DISTINCT FROM app.b017_support_digest_v1() OR st.enforcement_state NOT IN ('prepared','enforced') THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
  mode:=st.enforcement_state;
  SELECT x.* INTO asn FROM app.b017_assignments x WHERE x.org_id=l AND x.member_id=m.id;
  IF FOUND THEN
   ar:=asn.revision;
   IF asn.role_id IS NOT NULL THEN
    IF mode<>'enforced' THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
    SELECT q.* INTO r FROM app.b017_roles q WHERE q.org_id=l AND q.role_id=asn.role_id;
    IF NOT FOUND OR r.lifecycle<>'active' OR NOT app.b017_keys_supported_v1(r.keys) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
    ks:=r.keys; rr:=r.revision;
   ELSE ks:=app.b017_native_keys_v1(m.role); rr:=NULL; END IF;
  ELSE ks:=app.b017_native_keys_v1(m.role); ar:=NULL; rr:=NULL; END IF;
 END IF;
 IF ks IS NULL THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::uuid,NULL::uuid,NULL::text,NULL::text[],NULL::text,NULL::bigint,NULL::bigint,NULL::bigint,NULL::bytea; RETURN; END IF;
 digest:=sha256(convert_to(jsonb_build_array(1,a::text,p_session::text,p_org::text,l::text,p_env,m.id::text,m.role::text,m.status::text,m.is_billing_owner,to_char(m.updated_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),mode,st.authority_revision,asn.role_id::text,ar,rr,ks)::text,'UTF8'));
 RETURN QUERY SELECT 'ready',a,l,m.id,m.role::text,ks,mode,st.authority_revision,ar,rr,digest;
END $ctx$;
ALTER FUNCTION app.b017_recognized_keys_v1() OWNER TO b017_authority_owner;
ALTER FUNCTION app.b017_supported_keys_v1() OWNER TO b017_authority_owner;
ALTER FUNCTION app.b017_keys_supported_v1(text[]) OWNER TO b017_authority_owner;
ALTER FUNCTION app.b017_native_keys_v1(public.org_role) OWNER TO b017_authority_owner;
ALTER FUNCTION app.b017_support_digest_v1() OWNER TO b017_authority_owner;
ALTER FUNCTION app.b017_effective_context(uuid,uuid,text) OWNER TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_recognized_keys_v1(),app.b017_supported_keys_v1(),app.b017_keys_supported_v1(text[]),app.b017_native_keys_v1(public.org_role),app.b017_support_digest_v1() FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION app.b017_recognized_keys_v1(),app.b017_supported_keys_v1(),app.b017_keys_supported_v1(text[]),app.b017_native_keys_v1(public.org_role),app.b017_support_digest_v1() TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_effective_context(uuid,uuid,text) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION app.b017_effective_context(uuid,uuid,text) TO service_role;
