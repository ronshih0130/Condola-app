-- ISOLATED SOURCE FRAGMENT: UNPARSED, UNAPPLIED, NOT APPLY READY.
-- Requires stage 01 v2, trusted verified-cookie/consent/partner adapter and later complete safeguards.
-- `custom_roles` is the proposed management-only control, not an installed or enabled flag.
GRANT SELECT(key,value) ON public.platform_settings TO b017_authority_owner;
GRANT SELECT(feature_flags) ON public.organizations TO b017_authority_owner;
-- PostgreSQL requires UPDATE privilege for row-locking SELECT. The non-login
-- owner has no worker membership; false WITH CHECK blocks an UPDATE via RLS.
GRANT UPDATE(key) ON public.platform_settings TO b017_authority_owner;
GRANT UPDATE(id) ON public.organizations,public.org_members,public.auth_sessions TO b017_authority_owner;
CREATE POLICY b017_authority_control_select ON public.platform_settings FOR SELECT TO b017_authority_owner USING (key='custom_roles');
CREATE POLICY b017_authority_control_lock ON public.platform_settings FOR UPDATE TO b017_authority_owner USING (key='custom_roles') WITH CHECK (false);
CREATE POLICY b017_authority_org_lock ON public.organizations FOR UPDATE TO b017_authority_owner USING (true) WITH CHECK (false);
CREATE POLICY b017_authority_member_lock ON public.org_members FOR UPDATE TO b017_authority_owner USING (true) WITH CHECK (false);
CREATE POLICY b017_authority_session_lock ON public.auth_sessions FOR UPDATE TO b017_authority_owner USING (true) WITH CHECK (false);
-- Metadata-only audit; no direct role membership or access to historical audit payloads.
GRANT INSERT(org_id,actor_user_id,actor_role,table_name,row_id,action,new_row,request_id) ON public.audit_log TO b017_authority_owner;
CREATE POLICY b017_authority_audit_insert ON public.audit_log FOR INSERT TO b017_authority_owner WITH CHECK (table_name='b017_roles' AND action::text='insert');

-- Private fixed validation: Unicode whitespace/default-ignorable alone is not a name.
CREATE FUNCTION app.b017_role_name_valid(v text) RETURNS boolean
LANGUAGE sql IMMUTABLE STRICT SET search_path=pg_catalog AS $valid$
 SELECT char_length(v) BETWEEN 1 AND 120
 AND v !~ U&'[\0001-\001F\007F-\009F\202A-\202E\2066-\2069]'
 AND length(regexp_replace(v,U&'[\0009-\000D\0020\0085\00A0\1680\2000-\200A\2028-\2029\202F\205F\3000\00AD\034F\061C\115F-\1160\17B4-\17B5\180B-\180F\200B-\200F\202A-\202E\2060-\206F\3164\FE00-\FE0F\FEFF\FFA0\+01BCA0-\+01BCA3\+01D173-\+01D17A\+0E0000-\+0E0FFF]','','g'))>0
$valid$;
ALTER FUNCTION app.b017_role_name_valid(text) OWNER TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_role_name_valid(text) FROM PUBLIC,anon,authenticated,service_role;

-- Canonical comparison key: NFKC, explicit Unicode spaces/invisibles removed,
-- then ASCII case folding under C. Native UI labels and native codes are fixed.
-- This requires UTF8 and a reviewed PostgreSQL normalize() implementation.
CREATE FUNCTION app.b017_role_name_key(v text) RETURNS text
LANGUAGE sql IMMUTABLE STRICT SET search_path=pg_catalog AS $key$
 SELECT lower(regexp_replace(normalize(v,NFKC),
 U&'[\0009-\000D\0020\0085\00A0\1680\2000-\200A\2028-\2029\202F\205F\3000\00AD\034F\061C\115F-\1160\17B4-\17B5\180B-\180F\200B-\200F\202A-\202E\2060-\206F\3164\FE00-\FE0F\FEFF\FFA0\+01BCA0-\+01BCA3\+01D173-\+01D17A\+0E0000-\+0E0FFF]','','g') COLLATE "C")
$key$;
ALTER FUNCTION app.b017_role_name_key(text) OWNER TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_role_name_key(text) FROM PUBLIC,anon,authenticated,service_role;

-- The sole mutation is a new unassigned draft. No enrollment or assignment.
-- The server MUST validate the actual cookie and canonical consent/partner policy
-- in this transaction after waits and before COMMIT; context pins are not credentials.
CREATE FUNCTION app.b017_create_role(p_session uuid,p_org uuid,p_env text,p_request uuid,p_role uuid,p_expected_authority bigint,p_name text,p_keys text[])
RETURNS TABLE(outcome text,role_id uuid,role_revision bigint,authority_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET lock_timeout='500ms' AS $create$
DECLARE c record; f jsonb; flags jsonb; st app.b017_org_state%ROWTYPE; old app.b017_commands%ROWTYPE; n text; nk text; intent bytea; new_revision bigint; original_authority numeric;
BEGIN
 IF p_request IS NULL OR p_role IS NULL OR p_expected_authority IS NULL OR p_expected_authority<1 OR p_name IS NULL OR NOT app.b017_keys_supported_v1(p_keys) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 n:=btrim(p_name,E' \t\r\n');
 IF NOT app.b017_role_name_valid(n) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 nk:=app.b017_role_name_key(n);
 IF nk IS NULL OR char_length(nk) NOT BETWEEN 1 AND 120 OR nk=ANY(ARRAY['admin','manager','accountant','maintenance','管理員','經理','會計','維修']::text[]) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
 IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 -- Existing global row only: absence is OFF and no synthetic row is created.
 SELECT value INTO f FROM public.platform_settings WHERE key='custom_roles' FOR SHARE NOWAIT;
 IF NOT FOUND OR jsonb_typeof(f)<>'object' OR f->'enabled' IS DISTINCT FROM 'true'::jsonb OR jsonb_typeof(f->'allowed_org_ids') IS DISTINCT FROM 'array' THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(f->'allowed_org_ids') a(v) WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') OR NOT (f->'allowed_org_ids' @> jsonb_build_array(c.live_org_id::text)) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT o.feature_flags INTO flags FROM public.organizations o WHERE o.id=c.live_org_id AND o.environment::text='live' AND o.live_org_id IS NULL FOR UPDATE NOWAIT;
 IF NOT FOUND OR jsonb_typeof(flags)<>'object' OR flags->'custom_roles' IS DISTINCT FROM 'true'::jsonb THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 IF p_org<>c.live_org_id THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT s.* INTO st FROM app.b017_org_state s WHERE s.live_org_id=c.live_org_id FOR UPDATE NOWAIT;
 IF NOT FOUND OR st.capability_version<>1 OR st.support_manifest_sha256 IS DISTINCT FROM app.b017_support_digest_v1() OR st.enforcement_state NOT IN ('prepared','enforced') THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 PERFORM 1 FROM public.org_members m WHERE m.id=c.member_id AND m.org_id=c.live_org_id FOR SHARE NOWAIT;
 IF NOT FOUND THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 PERFORM 1 FROM public.auth_sessions s WHERE s.id=p_session AND s.user_id=c.actor_user_id AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() FOR SHARE NOWAIT;
 IF NOT FOUND THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 -- Org/state locks serialize role changes; actor is freshly resolved after waits.
 SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
 IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys OR c.live_org_id<>p_org THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 intent:=sha256(convert_to(jsonb_build_array(1,'role_create',p_org::text,c.member_id::text,p_request::text,p_role::text,p_expected_authority,n,p_keys)::text,'UTF8'));
 SELECT x.* INTO old FROM app.b017_commands x WHERE x.org_id=p_org AND x.actor_member_id=c.member_id AND x.request_id=p_request FOR UPDATE NOWAIT;
 IF FOUND THEN
   IF old.command<>'role_create' OR old.target_id IS DISTINCT FROM p_role OR old.intent_sha256 IS DISTINCT FROM intent THEN RETURN QUERY SELECT 'conflict',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
   -- Return only the original immutable result, not mutable current role state.
   IF jsonb_typeof(old.result_identity)<>'object' OR old.result_identity->>'role_id' IS DISTINCT FROM p_role::text OR old.result_identity->'role_revision' IS DISTINCT FROM '1'::jsonb OR jsonb_typeof(old.result_identity->'authority_revision') IS DISTINCT FROM 'number' THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
   original_authority:=(old.result_identity->>'authority_revision')::numeric;
   IF original_authority<1 OR original_authority>9223372036854775807 OR trunc(original_authority)<>original_authority THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
   RETURN QUERY SELECT 'replayed',p_role,1::bigint,original_authority::bigint; RETURN;
 END IF;
 IF st.authority_revision<>p_expected_authority THEN RETURN QUERY SELECT 'stale',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 INSERT INTO app.b017_roles(org_id,role_id,display_name,name_key,keys,revision,lifecycle,created_by,updated_by) VALUES(p_org,p_role,n,nk,p_keys,1,'draft',c.actor_user_id,c.actor_user_id);
 UPDATE app.b017_org_state AS state SET authority_revision=st.authority_revision+1,updated_at=clock_timestamp() WHERE state.live_org_id=p_org RETURNING state.authority_revision INTO new_revision;
 INSERT INTO app.b017_commands(org_id,actor_member_id,request_id,command,target_id,intent_sha256,expected_revisions,result_identity) VALUES(p_org,c.member_id,p_request,'role_create',p_role,intent,jsonb_build_object('authority',p_expected_authority),jsonb_build_object('role_id',p_role::text,'role_revision',1,'authority_revision',new_revision));
 INSERT INTO public.audit_log(org_id,actor_user_id,actor_role,table_name,row_id,action,new_row,request_id) VALUES(p_org,c.actor_user_id,'b017_authority_owner','b017_roles',p_role::text,'insert',jsonb_build_object('event','b017_role_created','role_id',p_role::text,'revision',1),p_request::text);
 RETURN QUERY SELECT 'created',p_role,1::bigint,new_revision;
END $create$;
ALTER FUNCTION app.b017_create_role(uuid,uuid,text,uuid,uuid,bigint,text,text[]) OWNER TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_create_role(uuid,uuid,text,uuid,uuid,bigint,text,text[]) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION app.b017_create_role(uuid,uuid,text,uuid,uuid,bigint,text,text[]) TO service_role;
