-- INACTIVE SOURCE FRAGMENT: UNPARSED, UNAPPLIED, NOT APPLY READY.
-- Requires reviewed 01-v2 and 02a-v2, the trusted authenticated adapter,
-- and all later raw guards, receipt immutability, worker fences and readiness.
-- This bounded operation refuses every role with any assignment reference.
CREATE POLICY b017_authority_role_edit_audit ON public.audit_log FOR INSERT TO b017_authority_owner
 WITH CHECK (table_name='b017_roles' AND action::text='update');

CREATE FUNCTION app.b017_edit_unassigned_role(p_session uuid,p_org uuid,p_env text,p_request uuid,p_role uuid,p_expected_role bigint,p_expected_authority bigint,p_name text,p_keys text[])
RETURNS TABLE(outcome text,role_id uuid,role_revision bigint,authority_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET lock_timeout='500ms' AS $edit$
DECLARE c record; f jsonb; flags jsonb; st app.b017_org_state%ROWTYPE; r app.b017_roles%ROWTYPE; old app.b017_commands%ROWTYPE; n text; nk text; intent bytea; new_role_revision bigint; new_authority_revision bigint; original_role numeric; original_authority numeric;
BEGIN
 IF p_request IS NULL OR p_role IS NULL OR p_expected_role IS NULL OR p_expected_role<1 OR p_expected_authority IS NULL OR p_expected_authority<1 OR p_name IS NULL OR NOT app.b017_keys_supported_v1(p_keys) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 n:=btrim(p_name,E' \t\r\n');
 IF NOT app.b017_role_name_valid(n) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 nk:=app.b017_role_name_key(n);
 IF nk IS NULL OR char_length(nk) NOT BETWEEN 1 AND 120 OR nk=ANY(ARRAY['admin','manager','accountant','maintenance','管理員','經理','會計','維修']::text[]) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
 IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT value INTO f FROM public.platform_settings WHERE key='custom_roles' FOR SHARE NOWAIT;
 IF NOT FOUND OR jsonb_typeof(f)<>'object' OR f->'enabled' IS DISTINCT FROM 'true'::jsonb OR jsonb_typeof(f->'allowed_org_ids') IS DISTINCT FROM 'array' THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(f->'allowed_org_ids') a(v) WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') OR NOT (f->'allowed_org_ids' @> jsonb_build_array(c.live_org_id::text)) THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT o.feature_flags INTO flags FROM public.organizations o WHERE o.id=c.live_org_id AND o.environment::text='live' AND o.live_org_id IS NULL FOR UPDATE NOWAIT;
 IF NOT FOUND OR jsonb_typeof(flags)<>'object' OR flags->'custom_roles' IS DISTINCT FROM 'true'::jsonb OR p_org<>c.live_org_id THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT s.* INTO st FROM app.b017_org_state s WHERE s.live_org_id=c.live_org_id FOR UPDATE NOWAIT;
 IF NOT FOUND OR st.capability_version<>1 OR st.support_manifest_sha256 IS DISTINCT FROM app.b017_support_digest_v1() OR st.enforcement_state NOT IN ('prepared','enforced') THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 PERFORM 1 FROM public.org_members m WHERE m.id=c.member_id AND m.org_id=c.live_org_id FOR SHARE NOWAIT;
 IF NOT FOUND THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 PERFORM 1 FROM public.auth_sessions s WHERE s.id=p_session AND s.user_id=c.actor_user_id AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() FOR SHARE NOWAIT;
 IF NOT FOUND THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
 IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys OR c.live_org_id<>p_org THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 -- Lock target role before receipt; the result is not used for replay validity.
 SELECT x.* INTO r FROM app.b017_roles x WHERE x.org_id=p_org AND x.role_id=p_role FOR UPDATE NOWAIT;
 intent:=sha256(convert_to(jsonb_build_array(1,'role_edit',p_org::text,c.member_id::text,p_request::text,p_role::text,p_expected_role,p_expected_authority,n,p_keys)::text,'UTF8'));
 SELECT x.* INTO old FROM app.b017_commands x WHERE x.org_id=p_org AND x.actor_member_id=c.member_id AND x.request_id=p_request FOR UPDATE NOWAIT;
 IF FOUND THEN
  IF old.command<>'role_edit' OR old.target_id IS DISTINCT FROM p_role OR old.intent_sha256 IS DISTINCT FROM intent THEN RETURN QUERY SELECT 'conflict',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
  IF jsonb_typeof(old.result_identity)<>'object' OR old.result_identity->>'role_id' IS DISTINCT FROM p_role::text OR jsonb_typeof(old.result_identity->'role_revision') IS DISTINCT FROM 'number' OR jsonb_typeof(old.result_identity->'authority_revision') IS DISTINCT FROM 'number' THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
  original_role:=(old.result_identity->>'role_revision')::numeric; original_authority:=(old.result_identity->>'authority_revision')::numeric;
  IF original_role<1 OR original_role>9223372036854775807 OR trunc(original_role)<>original_role OR original_authority<1 OR original_authority>9223372036854775807 OR trunc(original_authority)<>original_authority THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
  SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
  IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys OR c.live_org_id<>p_org THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
  RETURN QUERY SELECT 'replayed',p_role,original_role::bigint,original_authority::bigint; RETURN;
 END IF;
 -- No fallback from a missing/retired role and no caller-supplied in-use flag.
 IF r.role_id IS NULL OR r.lifecycle NOT IN ('draft','active') THEN RETURN QUERY SELECT 'unavailable',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 IF r.revision<>p_expected_role OR st.authority_revision<>p_expected_authority THEN RETURN QUERY SELECT 'stale',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 IF EXISTS(SELECT 1 FROM app.b017_assignments a WHERE a.org_id=p_org AND a.role_id=p_role) THEN RETURN QUERY SELECT 'in_use',NULL::uuid,NULL::bigint,NULL::bigint; RETURN; END IF;
 UPDATE app.b017_roles AS roles SET display_name=n,name_key=nk,keys=p_keys,revision=r.revision+1,updated_by=c.actor_user_id,updated_at=clock_timestamp() WHERE roles.org_id=p_org AND roles.role_id=p_role RETURNING roles.revision INTO new_role_revision;
 UPDATE app.b017_org_state AS state SET authority_revision=st.authority_revision+1,updated_at=clock_timestamp() WHERE state.live_org_id=p_org RETURNING state.authority_revision INTO new_authority_revision;
 INSERT INTO app.b017_commands(org_id,actor_member_id,request_id,command,target_id,intent_sha256,expected_revisions,result_identity) VALUES(p_org,c.member_id,p_request,'role_edit',p_role,intent,jsonb_build_object('role',p_expected_role,'authority',p_expected_authority),jsonb_build_object('role_id',p_role::text,'role_revision',new_role_revision,'authority_revision',new_authority_revision));
 INSERT INTO public.audit_log(org_id,actor_user_id,actor_role,table_name,row_id,action,new_row,request_id) VALUES(p_org,c.actor_user_id,'b017_authority_owner','b017_roles',p_role::text,'update',jsonb_build_object('event','b017_unassigned_role_edited','role_id',p_role::text,'revision',new_role_revision),p_request::text);
 SELECT * INTO c FROM app.b017_effective_context(p_session,p_org,p_env);
 IF c.status IS DISTINCT FROM 'ready' OR c.native_role IS DISTINCT FROM 'admin' OR NOT ('team.manage'=ANY(c.effective_keys)) OR NOT p_keys <@ c.effective_keys OR c.live_org_id<>p_org THEN RAISE EXCEPTION 'B017 unavailable' USING ERRCODE='42501'; END IF;
 RETURN QUERY SELECT 'updated',p_role,new_role_revision,new_authority_revision;
END $edit$;
ALTER FUNCTION app.b017_edit_unassigned_role(uuid,uuid,text,uuid,uuid,bigint,bigint,text,text[]) OWNER TO b017_authority_owner;
REVOKE ALL ON FUNCTION app.b017_edit_unassigned_role(uuid,uuid,text,uuid,uuid,bigint,bigint,text,text[]) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION app.b017_edit_unassigned_role(uuid,uuid,text,uuid,uuid,bigint,bigint,text,text[]) TO service_role;
