\set ON_ERROR_STOP on
BEGIN;
\ir sql/guard.sql
\ir sql/inventory.sql
\ir sql/preflight.sql
\ir sql/snapshot.sql
ROLLBACK;
