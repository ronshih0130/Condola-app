\set ON_ERROR_STOP on
BEGIN;
\ir sql/guard.sql
\ir sql/inventory.sql
\ir sql/down.sql
\ir sql/assert-sealed.sql
\ir sql/snapshot.sql
\ir sql/match.sql
\ir sql/drop.sql
\ir sql/preflight.sql
\ir sql/snapshot.sql
\set expected :original
\ir sql/match.sql
COMMIT;
