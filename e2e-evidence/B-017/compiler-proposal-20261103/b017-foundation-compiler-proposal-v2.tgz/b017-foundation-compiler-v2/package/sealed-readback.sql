\set ON_ERROR_STOP on
BEGIN;
\ir sql/guard.sql
\ir sql/inventory.sql
\ir sql/assert-sealed.sql
\ir sql/snapshot.sql
\ir sql/match.sql
ROLLBACK;
