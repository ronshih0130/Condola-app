-- Session-local inventory; created only inside a bounded proof transaction.
CREATE TEMP TABLE b17_fn (signature text PRIMARY KEY) ON COMMIT DROP;
INSERT INTO pg_temp.b17_fn VALUES
('app.b017_recognized_keys_v1()'),
('app.b017_supported_keys_v1()'),
('app.b017_keys_supported_v1(text[])'),
('app.b017_native_keys_v1(public.org_role)'),
('app.b017_support_digest_v1()'),
('app.b017_effective_context(uuid,uuid,text)'),
('app.b017_role_name_valid(text)'),
('app.b017_role_name_key(text)'),
('app.b017_create_role(uuid,uuid,text,uuid,uuid,bigint,text,text[])'),
('app.b017_edit_unassigned_role(uuid,uuid,text,uuid,uuid,bigint,bigint,text,text[])');
CREATE TEMP TABLE b17_tab (rel text PRIMARY KEY) ON COMMIT DROP;
INSERT INTO pg_temp.b17_tab VALUES
('app.b017_org_state'),
('app.b017_roles'),
('app.b017_assignments'),
('app.b017_commands');
CREATE TEMP TABLE b17_owner (rol text PRIMARY KEY) ON COMMIT DROP;
INSERT INTO pg_temp.b17_owner VALUES
('b017_authority_owner'),
('b017_domain_owner');
CREATE TEMP TABLE b17_policy(rel text, pol text, PRIMARY KEY(rel,pol)) ON COMMIT DROP;
INSERT INTO pg_temp.b17_policy VALUES
('app.b017_org_state','b017_owner'),
('app.b017_roles','b017_owner'),
('app.b017_assignments','b017_owner'),
('app.b017_commands','b017_owner'),
('public.auth_sessions','b017_authority_session_read'),
('public.organizations','b017_authority_org_read'),
('public.org_members','b017_authority_member_read'),
('public.platform_settings','b017_authority_control_select'),
('public.platform_settings','b017_authority_control_lock'),
('public.organizations','b017_authority_org_lock'),
('public.org_members','b017_authority_member_lock'),
('public.auth_sessions','b017_authority_session_lock'),
('public.audit_log','b017_authority_audit_insert'),
('public.audit_log','b017_authority_role_edit_audit');
