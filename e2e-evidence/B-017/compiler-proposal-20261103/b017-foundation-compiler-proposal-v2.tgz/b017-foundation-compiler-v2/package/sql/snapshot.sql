-- One canonical JSON result marker; includes relevant definitions/ACLs, not business values.
WITH covered AS (
 SELECT c.oid,c.oid::regclass::text rel,c.relowner,c.relacl,c.relrowsecurity,c.relforcerowsecurity
 FROM pg_class c WHERE c.oid IN (SELECT to_regclass(rel) FROM pg_temp.b17_tab
  UNION SELECT to_regclass(rel) FROM pg_temp.b17_policy)
), relation_data AS (
 SELECT rel, pg_get_userbyid(relowner) owner,relrowsecurity,relforcerowsecurity,
 (SELECT coalesce(jsonb_agg(jsonb_build_array(pg_get_userbyid(a.grantor),CASE WHEN a.grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(a.grantee) END,a.privilege_type,a.is_grantable) ORDER BY a.grantor,a.grantee,a.privilege_type),'[]') FROM aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a) acl,
 (SELECT coalesce(jsonb_agg(jsonb_build_array(a.attnum,a.attname,format_type(a.atttypid,a.atttypmod),a.attnotnull,a.attidentity,a.attgenerated,pg_get_expr(ad.adbin,ad.adrelid),
 (SELECT coalesce(jsonb_agg(jsonb_build_array(pg_get_userbyid(z.grantor),CASE WHEN z.grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(z.grantee) END,z.privilege_type,z.is_grantable) ORDER BY z.grantor,z.grantee,z.privilege_type),'[]') FROM aclexplode(a.attacl) z)) ORDER BY a.attnum),'[]') FROM pg_attribute a LEFT JOIN pg_attrdef ad ON ad.adrelid=a.attrelid AND ad.adnum=a.attnum WHERE a.attrelid=c.oid AND a.attnum>0 AND NOT a.attisdropped) cols,
 (SELECT coalesce(jsonb_agg(jsonb_build_array(k.conname,pg_get_constraintdef(k.oid)) ORDER BY k.conname),'[]') FROM pg_constraint k WHERE k.conrelid=c.oid) constraints,
 (SELECT coalesce(jsonb_agg(pg_get_indexdef(i.indexrelid) ORDER BY i.indexrelid::regclass::text),'[]') FROM pg_index i WHERE i.indrelid=c.oid) indexes,
 (SELECT coalesce(jsonb_agg(jsonb_build_array(p.polname,p.polcmd,p.polpermissive,(SELECT array_agg(CASE WHEN v=0 THEN 'PUBLIC' ELSE pg_get_userbyid(v) END ORDER BY v) FROM unnest(p.polroles) v),pg_get_expr(p.polqual,c.oid),pg_get_expr(p.polwithcheck,c.oid)) ORDER BY p.polname),'[]') FROM pg_policy p WHERE p.polrelid=c.oid) policies
 FROM covered c
), routines AS (
 SELECT i.signature,pg_get_functiondef(p.oid) def,pg_get_userbyid(p.proowner) owner,p.proacl::text acl FROM pg_temp.b17_fn i JOIN pg_proc p ON p.oid=to_regprocedure(i.signature)
), controls AS (
 SELECT jsonb_build_array(
   (SELECT encode(sha256(convert_to(coalesce(jsonb_agg(jsonb_build_array(key,value,description,updated_at) ORDER BY key)::text,'[]'),'UTF8')),'hex') FROM public.platform_settings),
   (SELECT encode(sha256(convert_to(coalesce(jsonb_agg(jsonb_build_array(id,environment,live_org_id,feature_flags) ORDER BY id)::text,'[]'),'UTF8')),'hex') FROM public.organizations)) hashes
)
SELECT jsonb_build_object('relations',(SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rel) FROM relation_data r),
 'routines',(SELECT coalesce(jsonb_agg(to_jsonb(f) ORDER BY f.signature),'[]') FROM routines f),
 'owners',(SELECT coalesce(jsonb_agg(jsonb_build_array(r.rolname,r.rolcanlogin,r.rolsuper,r.rolcreaterole,r.rolbypassrls,r.rolinherit) ORDER BY r.rolname),'[]') FROM pg_roles r JOIN pg_temp.b17_owner i ON i.rol=r.rolname),
 'native_acl',(
  SELECT jsonb_agg(to_jsonb(ac) ORDER BY obj,grantee_name,privilege_type,grantor_name,is_grantable) FROM (
   SELECT 'schema.'||n.nspname obj,CASE WHEN a.grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(a.grantee) END grantee_name,pg_get_userbyid(a.grantor) grantor_name,a.privilege_type,a.is_grantable
   FROM pg_namespace n, LATERAL aclexplode(coalesce(n.nspacl,acldefault('n',n.nspowner))) a WHERE n.nspname IN('public','app','auth')
   UNION ALL SELECT 'auth.uid()',CASE WHEN a.grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(a.grantee) END,pg_get_userbyid(a.grantor),a.privilege_type,a.is_grantable
   FROM pg_proc p,LATERAL aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a WHERE p.oid=to_regprocedure('auth.uid()')
  ) ac),
 'parent_triggers',(SELECT coalesce(jsonb_object_agg(t.oid::text,jsonb_build_object(
   'relation', t.tgrelid::regclass::text,'name',t.tgname,'enabled',t.tgenabled,'internal',t.tgisinternal,
   'fingerprint',encode(sha256(convert_to(jsonb_build_array(to_jsonb(t),pg_get_triggerdef(t.oid))::text,'UTF8')),'hex'))),'{}'::jsonb)
   FROM pg_trigger t WHERE t.tgrelid IN ('public.organizations'::regclass,'public.org_members'::regclass)),
 'reverse_dependencies',(SELECT coalesce(jsonb_agg(jsonb_build_array(d.classid::regclass::text,d.objid,d.objsubid,d.refclassid::regclass::text,d.refobjid,d.refobjsubid,d.deptype) ORDER BY d.classid,d.objid,d.objsubid,d.refclassid,d.refobjid,d.refobjsubid,d.deptype),'[]') FROM pg_depend d WHERE
   (d.refclassid='pg_class'::regclass AND d.refobjid IN(SELECT to_regclass(rel) FROM pg_temp.b17_tab)) OR
   (d.refclassid='pg_proc'::regclass AND d.refobjid IN(SELECT to_regprocedure(signature) FROM pg_temp.b17_fn))),
 'controls',(SELECT hashes FROM controls))::text AS snapshot
\gset
SELECT 'B017_SNAPSHOT=' || :'snapshot';
