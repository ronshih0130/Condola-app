-- Called with both captured snapshots in the same install transaction.
-- Private child FKs generate these six internal triggers on ordinary public parents.
WITH expected(child,src,parent,dst) AS (VALUES
 ('app.b017_org_state'::regclass, ARRAY['live_org_id'], 'public.organizations'::regclass, ARRAY['id']),
 ('app.b017_assignments'::regclass, ARRAY['org_id','member_id'], 'public.org_members'::regclass, ARRAY['org_id','id']),
 ('app.b017_commands'::regclass, ARRAY['org_id','actor_member_id'], 'public.org_members'::regclass, ARRAY['org_id','id'])
), matched AS (
 SELECT e.child,e.parent,c.oid fk
 FROM expected e JOIN pg_constraint c ON c.conrelid=e.child AND c.confrelid=e.parent AND c.contype='f'
 JOIN pg_class p ON p.oid=e.parent AND p.relkind='r' AND NOT p.relispartition
 WHERE c.conparentid=0 AND c.convalidated AND NOT c.condeferrable AND NOT c.condeferred
   AND c.confupdtype='a' AND c.confdeltype='a' AND c.confmatchtype='s'
   AND ARRAY(SELECT a.attname::text FROM unnest(c.conkey) WITH ORDINALITY u(n,i)
       JOIN pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=u.n ORDER BY u.i)=e.src
   AND ARRAY(SELECT a.attname::text FROM unnest(c.confkey) WITH ORDINALITY u(n,i)
       JOIN pg_attribute a ON a.attrelid=c.confrelid AND a.attnum=u.n ORDER BY u.i)=e.dst
), allowed AS (
 SELECT m.fk,m.child,t.oid tid,t.tgtype
 FROM matched m JOIN pg_trigger t ON t.tgconstraint=m.fk AND t.tgrelid=m.parent AND t.tgconstrrelid=m.child
 JOIN pg_proc f ON f.oid=t.tgfoid JOIN pg_namespace n ON n.oid=f.pronamespace
 WHERE n.nspname='pg_catalog' AND f.pronargs=0 AND t.tgisinternal AND t.tgenabled='O'
   AND t.tgparentid=0 AND NOT t.tgdeferrable AND NOT t.tginitdeferred
   AND ((t.tgtype=9 AND f.proname='RI_FKey_noaction_del') OR (t.tgtype=17 AND f.proname='RI_FKey_noaction_upd'))
)
SELECT 1 / (((SELECT count(*)=3 AND count(DISTINCT child)=3 FROM matched)
 AND (SELECT count(*)=6 AND count(DISTINCT (fk,tgtype))=6 FROM allowed)
 AND NOT EXISTS(SELECT 1 FROM allowed WHERE :'parents_before'::jsonb ? tid::text)
 AND (((:'snapshot'::jsonb)->'parent_triggers') - ARRAY(SELECT tid::text FROM allowed))=:'parents_before'::jsonb)::integer);
