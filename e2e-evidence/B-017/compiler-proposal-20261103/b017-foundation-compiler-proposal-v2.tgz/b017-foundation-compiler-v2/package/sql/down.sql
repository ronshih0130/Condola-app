-- Called exclusively by runner, only on a baseline-bound sealed empty target.
-- Acquire exclusive locks before the runner verifies the sealed fingerprint.
LOCK TABLE app.b017_org_state,app.b017_roles,app.b017_assignments,app.b017_commands IN ACCESS EXCLUSIVE MODE NOWAIT;
