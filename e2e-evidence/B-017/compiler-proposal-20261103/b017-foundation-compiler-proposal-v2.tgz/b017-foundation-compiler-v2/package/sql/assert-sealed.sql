DO $verify$
DECLARE x record; u text; privilege text; column_name text; nonempty boolean; blocked boolean;
BEGIN
 IF (SELECT count(*) FROM pg_roles r JOIN pg_temp.b17_owner i ON r.rolname=i.rol)<>2
 OR EXISTS(SELECT 1 FROM pg_roles r JOIN pg_temp.b17_owner i ON i.rol=r.rolname
   WHERE r.rolcanlogin OR r.rolsuper OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication OR r.rolbypassrls OR r.rolinherit
   OR has_schema_privilege(r.oid,'app','CREATE') OR has_schema_privilege(r.oid,'public','CREATE'))
 OR EXISTS(SELECT 1 FROM pg_auth_members a WHERE a.roleid IN(SELECT r.oid FROM pg_roles r JOIN pg_temp.b17_owner i ON i.rol=r.rolname)
   OR a.member IN(SELECT r.oid FROM pg_roles r JOIN pg_temp.b17_owner i ON i.rol=r.rolname))
 THEN RAISE EXCEPTION 'Private owner or membership seal failed'; END IF;
 IF EXISTS (SELECT 1 FROM pg_temp.b17_policy i LEFT JOIN pg_policy p ON p.polname=i.pol AND p.polrelid=to_regclass(i.rel)
   WHERE p.oid IS NULL OR p.polroles<>ARRAY[to_regrole('b017_authority_owner')::oid])
 THEN RAISE EXCEPTION 'Policy inventory mismatch'; END IF;
 IF EXISTS (SELECT 1 FROM pg_temp.b17_tab i JOIN pg_attribute a ON a.attrelid=to_regclass(i.rel) WHERE a.attidentity<>'' OR a.attgenerated<>'')
 THEN RAISE EXCEPTION 'Unexpected identity/generated private column'; END IF;
 FOR x IN SELECT signature,to_regprocedure(signature) fn FROM pg_temp.b17_fn LOOP
  IF x.fn IS NULL OR NOT EXISTS(SELECT 1 FROM pg_proc p WHERE p.oid=x.fn AND p.proowner=to_regrole('b017_authority_owner'))
   OR EXISTS(SELECT 1 FROM pg_proc p,LATERAL aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a WHERE p.oid=x.fn AND a.grantee<>p.proowner)
  THEN RAISE EXCEPTION 'Unexpected function ownership/ACL on %',x.signature; END IF;
 END LOOP;
 FOR x IN SELECT i.rel,to_regclass(i.rel) id FROM pg_temp.b17_tab i LOOP
  IF x.id IS NULL OR NOT EXISTS(SELECT 1 FROM pg_class c WHERE c.oid=x.id AND c.relkind='r' AND c.relrowsecurity AND c.relforcerowsecurity AND c.relowner=to_regrole('b017_authority_owner'))
   OR EXISTS(SELECT 1 FROM pg_class c,LATERAL aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a WHERE c.oid=x.id AND a.grantee<>c.relowner)
   OR EXISTS(SELECT 1 FROM pg_attribute t,LATERAL aclexplode(t.attacl) a WHERE t.attrelid=x.id AND a.grantee<>to_regrole('b017_authority_owner'))
  THEN RAISE EXCEPTION 'Unexpected table/column ownership or ACL on %',x.rel; END IF;
  EXECUTE format('SELECT EXISTS(SELECT 1 FROM %s)',x.rel) INTO nonempty;
  IF nonempty THEN RAISE EXCEPTION 'Installed private table contains rows: %',x.rel; END IF;
 END LOOP;
 FOR u IN SELECT jsonb_array_elements_text(current_setting('b017_compiler.runtime')::jsonb) LOOP
  IF EXISTS(SELECT 1 FROM pg_temp.b17_owner o WHERE pg_has_role(u,o.rol,'MEMBER') OR pg_has_role(u,o.rol,'SET'))
   OR EXISTS(SELECT 1 FROM pg_roles r WHERE (r.rolsuper OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication OR r.rolcanlogin OR r.rolname IN ('pg_read_all_data','pg_write_all_data','pg_execute_server_program','pg_read_server_files','pg_write_server_files','pg_signal_backend','pg_database_owner')) AND pg_has_role(u,r.oid,'MEMBER'))
   OR has_schema_privilege(u,'app','CREATE') OR has_schema_privilege(u,'public','CREATE')
  THEN RAISE EXCEPTION 'Runtime privilege/role chain not isolated: %',u; END IF;
  FOR x IN SELECT signature FROM pg_temp.b17_fn LOOP
   IF has_function_privilege(u,x.signature,'EXECUTE') THEN RAISE EXCEPTION 'Runtime execute leakage'; END IF;
  END LOOP;
  FOR x IN SELECT rel FROM pg_temp.b17_tab LOOP
   FOREACH privilege IN ARRAY ARRAY['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'] LOOP
    IF has_table_privilege(u,x.rel,privilege) THEN RAISE EXCEPTION 'Runtime table access'; END IF;
   END LOOP;
   FOREACH privilege IN ARRAY ARRAY['SELECT','INSERT','UPDATE','REFERENCES'] LOOP
    IF has_any_column_privilege(u,x.rel,privilege) THEN RAISE EXCEPTION 'Runtime column access'; END IF;
   END LOOP;
  END LOOP;
 END LOOP;
END $verify$;
