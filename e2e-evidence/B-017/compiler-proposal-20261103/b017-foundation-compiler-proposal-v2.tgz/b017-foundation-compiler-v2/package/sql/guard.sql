-- Inputs are supplied by the isolated operator runner. No credentials in receipt.
SET LOCAL check_function_bodies = on;
SET LOCAL search_path = pg_catalog;
SET LOCAL lock_timeout = '2s';
SET LOCAL statement_timeout = '30s';
SET LOCAL idle_in_transaction_session_timeout = '60s';
SELECT set_config('b017_compiler.cluster', :'sysid', true),
       set_config('b017_compiler.db', :'dbname', true),
       set_config('b017_compiler.operator', :'operator', true),
       set_config('b017_compiler.runtime', :'runtime_json', true),
       set_config('b017_compiler.pgdata', :'pgdata', true);
DO $guard$
DECLARE runtime_users jsonb := current_setting('b017_compiler.runtime')::jsonb;
BEGIN
 IF current_setting('check_function_bodies') IS DISTINCT FROM 'on'
    OR system_user IS DISTINCT FROM ('peer:' || current_user)
    OR current_setting('hba_file') IS DISTINCT FROM (current_setting('data_directory') || '/pg_hba.conf')
    OR current_database() <> current_setting('b017_compiler.db')
    OR current_database() !~ '^condola_b017_compiler_[a-z0-9_]+$'
    OR current_user <> current_setting('b017_compiler.operator') OR current_user <> session_user
    OR NOT (SELECT rolsuper FROM pg_roles WHERE rolname=current_user)
    OR (SELECT system_identifier::text FROM pg_control_system()) <> current_setting('b017_compiler.cluster')
    OR inet_client_addr() IS NOT NULL OR pg_is_in_recovery()
    OR current_setting('data_directory')<>current_setting('b017_compiler.pgdata')
    OR current_setting('listen_addresses')<>''
    OR EXISTS(SELECT 1 FROM pg_prepared_xacts)
    OR EXISTS(SELECT 1 FROM pg_subscription)
    OR EXISTS(SELECT 1 FROM pg_event_trigger WHERE evtenabled<>'D')
    OR current_setting('server_version_num')::integer NOT BETWEEN 160000 AND 179999
    OR current_setting('server_encoding') <> 'UTF8'
    OR EXISTS(SELECT 1 FROM pg_roles WHERE rolcanlogin AND rolname<>current_user)
    OR EXISTS(SELECT 1 FROM pg_stat_activity WHERE backend_type='client backend'
           AND pid<>pg_backend_pid())
 THEN RAISE EXCEPTION 'Dedicated offline compiler cluster, socket and operator proof required'; END IF;
 IF jsonb_typeof(runtime_users) IS DISTINCT FROM 'array'
    OR NOT runtime_users @> '["anon","authenticated","service_role"]'::jsonb
    OR EXISTS(SELECT 1 FROM jsonb_array_elements_text(runtime_users) n(role_name)
        LEFT JOIN pg_roles r ON r.rolname=n.role_name WHERE r.oid IS NULL OR r.rolcanlogin OR r.rolsuper OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication OR r.rolname=current_user)
 THEN RAISE EXCEPTION 'Actual runtime identity inventory cannot be isolated'; END IF;
 -- The outer flock on the actual isolated cluster data directory serializes operators. This advisory lock is database-local only.
 IF NOT pg_try_advisory_xact_lock(170017, 170001) THEN RAISE EXCEPTION 'Compiler operation busy'; END IF;
END $guard$;
SET LOCAL timezone = 'UTC';
SET LOCAL datestyle = 'ISO, YMD';
