-- A mismatch raises division_by_zero before any caller can COMMIT.
SELECT 1 / ((encode(sha256(convert_to(:'snapshot','UTF8')),'hex')=:'expected')::integer);
