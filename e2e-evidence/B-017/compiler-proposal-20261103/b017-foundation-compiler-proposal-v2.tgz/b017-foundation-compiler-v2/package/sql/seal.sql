-- Only the declared future entrypoints have explicit service grants in the source.
-- Reject unexpected default named grantees; do not repair them with broad revokes.
DO $seal$
DECLARE x record; name text; grantee_name text; col text;
BEGIN
 FOR x IN SELECT i.signature,to_regprocedure(i.signature) AS id FROM pg_temp.b17_fn i LOOP
  IF x.id IS NULL OR EXISTS(SELECT 1 FROM pg_proc p, LATERAL aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
     WHERE p.oid=x.id AND a.grantee<>p.proowner AND a.grantee<>0 AND a.grantee NOT IN (SELECT oid FROM pg_roles WHERE rolname IN ('anon','authenticated','service_role')))
  THEN RAISE EXCEPTION 'Function privilege or identity conflict on %',x.signature; END IF;
  EXECUTE format('REVOKE ALL PRIVILEGES ON FUNCTION %s FROM PUBLIC, anon, authenticated, service_role',x.signature);
  FOR name IN SELECT jsonb_array_elements_text(current_setting('b017_compiler.runtime')::jsonb) LOOP
   EXECUTE format('REVOKE ALL PRIVILEGES ON FUNCTION %s FROM %I',x.signature,name);
  END LOOP;
 END LOOP;
 FOR x IN SELECT i.rel,to_regclass(i.rel) AS id FROM pg_temp.b17_tab i LOOP
  IF x.id IS NULL OR EXISTS(SELECT 1 FROM pg_class c,LATERAL aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a
    WHERE c.oid=x.id AND a.grantee<>c.relowner AND a.grantee<>0 AND a.grantee NOT IN(SELECT oid FROM pg_roles WHERE rolname IN('anon','authenticated','service_role')))
   OR EXISTS(SELECT 1 FROM pg_attribute t CROSS JOIN LATERAL aclexplode(t.attacl) a WHERE t.attrelid=x.id AND a.grantee<>to_regrole('b017_authority_owner') AND a.grantee<>0 AND a.grantee NOT IN(SELECT oid FROM pg_roles WHERE rolname IN('anon','authenticated','service_role')))
  THEN RAISE EXCEPTION 'Private ACL conflict on %',x.rel; END IF;
  EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE %s FROM PUBLIC, anon, authenticated, service_role',x.rel);
  FOR col IN SELECT attname FROM pg_attribute WHERE attrelid=x.id AND attnum>0 AND NOT attisdropped LOOP
   EXECUTE format('REVOKE ALL PRIVILEGES (%I) ON TABLE %s FROM PUBLIC, anon, authenticated, service_role',col,x.rel);
  END LOOP;
  FOR name IN SELECT jsonb_array_elements_text(current_setting('b017_compiler.runtime')::jsonb) LOOP
   EXECUTE format('REVOKE ALL PRIVILEGES ON TABLE %s FROM %I',x.rel,name);
   FOR col IN SELECT attname FROM pg_attribute WHERE attrelid=x.id AND attnum>0 AND NOT attisdropped LOOP
    EXECUTE format('REVOKE ALL PRIVILEGES (%I) ON TABLE %s FROM %I',col,x.rel,name);
   END LOOP;
  END LOOP;
 END LOOP;
END $seal$;
