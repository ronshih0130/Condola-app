DO $down$
DECLARE x record;
BEGIN
 FOR x IN SELECT * FROM pg_temp.b17_policy WHERE rel LIKE 'public.%' ORDER BY rel,pol LOOP
  EXECUTE format('DROP POLICY %I ON %s RESTRICT',x.pol,x.rel);
 END LOOP;
END $down$;
DROP FUNCTION app.b017_edit_unassigned_role(uuid,uuid,text,uuid,uuid,bigint,bigint,text,text[]) RESTRICT;
DROP FUNCTION app.b017_create_role(uuid,uuid,text,uuid,uuid,bigint,text,text[]) RESTRICT;
DROP FUNCTION app.b017_effective_context(uuid,uuid,text) RESTRICT;
DROP FUNCTION app.b017_role_name_valid(text) RESTRICT;
DROP FUNCTION app.b017_role_name_key(text) RESTRICT;
DROP TABLE app.b017_commands RESTRICT;
DROP TABLE app.b017_assignments RESTRICT;
DROP TABLE app.b017_roles RESTRICT;
DROP TABLE app.b017_org_state RESTRICT;
DROP FUNCTION app.b017_support_digest_v1() RESTRICT;
DROP FUNCTION app.b017_native_keys_v1(public.org_role) RESTRICT;
DROP FUNCTION app.b017_keys_supported_v1(text[]) RESTRICT;
DROP FUNCTION app.b017_supported_keys_v1() RESTRICT;
DROP FUNCTION app.b017_recognized_keys_v1() RESTRICT;
REVOKE INSERT(org_id,actor_user_id,actor_role,table_name,row_id,action,new_row,request_id) ON public.audit_log FROM b017_authority_owner;
REVOKE SELECT(id,user_id,expires_at,revoked_at),UPDATE(id) ON public.auth_sessions FROM b017_authority_owner;
REVOKE SELECT(id,environment,live_org_id,feature_flags),UPDATE(id) ON public.organizations FROM b017_authority_owner;
REVOKE SELECT(id,org_id,user_id,role,status,is_billing_owner,updated_at),UPDATE(id) ON public.org_members FROM b017_authority_owner;
REVOKE SELECT(key,value),UPDATE(key) ON public.platform_settings FROM b017_authority_owner;
REVOKE EXECUTE ON FUNCTION auth.uid() FROM b017_authority_owner;
REVOKE USAGE ON SCHEMA app,public,auth FROM b017_authority_owner;
-- DROP ROLE checks dependencies cluster-wide, fails atomically if any remain.
DROP ROLE b017_domain_owner;
DROP ROLE b017_authority_owner;
