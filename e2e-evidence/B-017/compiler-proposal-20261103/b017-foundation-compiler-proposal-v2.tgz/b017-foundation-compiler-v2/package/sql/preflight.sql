DO $pre$
DECLARE x record;
BEGIN
 IF EXISTS(SELECT 1 FROM pg_roles r JOIN pg_temp.b17_owner i ON i.rol=r.rolname)
 OR EXISTS(SELECT 1 FROM pg_temp.b17_tab i WHERE to_regclass(i.rel) IS NOT NULL)
 OR EXISTS(SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
      JOIN pg_temp.b17_fn i ON p.proname=split_part(split_part(i.signature,'.',2),'(',1) WHERE n.nspname='app')
 OR EXISTS(SELECT 1 FROM pg_policy p JOIN pg_temp.b17_policy i ON p.polname=i.pol AND p.polrelid=to_regclass(i.rel))
 THEN RAISE EXCEPTION 'An expected new object or overload already exists'; END IF;
 IF to_regprocedure('auth.uid()') IS NULL OR to_regtype('public.org_role') IS NULL
    OR to_regclass('public.platform_settings') IS NULL OR to_regclass('public.organizations') IS NULL
    OR to_regclass('public.org_members') IS NULL OR to_regclass('public.auth_sessions') IS NULL OR to_regclass('public.audit_log') IS NULL
 THEN RAISE EXCEPTION 'Baseline source object missing'; END IF;
 FOR x IN SELECT * FROM (VALUES ('public.auth_sessions','id user_id expires_at revoked_at'),
    ('public.organizations','id environment live_org_id feature_flags'), ('public.org_members','id org_id user_id role status is_billing_owner updated_at'),
    ('public.platform_settings','key value'),('public.audit_log','org_id actor_user_id actor_role table_name row_id action new_row request_id')) AS v(rel,cols) LOOP
  IF EXISTS(SELECT 1 FROM unnest(string_to_array(x.cols,' ')) c WHERE NOT EXISTS(SELECT 1 FROM pg_attribute a WHERE a.attrelid=to_regclass(x.rel) AND a.attname=c AND a.attnum>0 AND NOT a.attisdropped))
  THEN RAISE EXCEPTION 'Source column missing for %',x.rel; END IF;
 END LOOP;
 IF EXISTS (SELECT 1 FROM public.platform_settings WHERE key='custom_roles')
 OR EXISTS (SELECT 1 FROM public.organizations WHERE feature_flags ? 'custom_roles')
 THEN RAISE EXCEPTION 'Compiler baseline requires absent management setting and org key'; END IF;
 IF normalize('Ａ',NFKC)<>'A' OR octet_length(sha256(convert_to('B017','UTF8')))<>32 THEN RAISE EXCEPTION 'Compiler encoding primitive mismatch'; END IF;
END $pre$;
